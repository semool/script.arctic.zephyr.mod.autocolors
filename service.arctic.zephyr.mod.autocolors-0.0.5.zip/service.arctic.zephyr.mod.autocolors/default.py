import xbmc, xbmcgui, xbmcaddon

addon = xbmcaddon.Addon("service.arctic.zephyr.mod.autocolors")
addon.openSettings()
